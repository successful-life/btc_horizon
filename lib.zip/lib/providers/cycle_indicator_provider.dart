import 'package:btc_horizon/data/cycle_indicator_config.dart';
import 'package:btc_horizon/enums/cycle_indicator_type.dart';
import 'package:btc_horizon/enums/cycle_timing_estimate_type.dart';
import 'package:btc_horizon/models/cycle_indicator_model.dart';
import 'package:btc_horizon/models/cycle_indicators.dart';
import 'package:btc_horizon/models/indicator_summary_model.dart';
import 'package:btc_horizon/models/trend_chart_data_model.dart';
import 'package:btc_horizon/models/trend_detail_model.dart';
import 'package:btc_horizon/models/weighted_score_model.dart';
import 'package:btc_horizon/providers/cycle_timing_analysis_provider.dart';
import 'package:btc_horizon/providers/fear_greed_provider.dart';
import 'package:btc_horizon/providers/funding_rate_provider.dart';
import 'package:btc_horizon/providers/mvrv_z_score_provider.dart';
import 'package:btc_horizon/providers/trend_provider.dart';
import 'package:btc_horizon/utils/cycle_indicator_calculator.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:intl/intl.dart';

final cycleIndicatorProvider = Provider<CycleIndicators>((ref) {
  final valuationList = <WeightedScore>[];
  final cycleTimingList = <WeightedScore>[];
  final sentimentList = <WeightedScore>[];

  // 각 카테고리의 개별 Weight 합은 1이어야 함

  const mvrvWeight = 1.0;

  const cycleTimingAnalysisWeight = 1.0;

  const fearGreedWeight = 0.9;
  const fundingRateWeight = 0.1;

  // ================================
  // 1. Valuation & On-chain
  // ================================

  // 1-1. MVRV Z-Score
  final mvrvAsync = ref.watch(mvrvZScoreProvider);
  final IndicatorSummaryModel mvrvIndicator;

  if (mvrvAsync.isLoading) {
    mvrvIndicator = const IndicatorSummaryModel(
      label: 'MVRV Z-Score',
      value: '로딩 중...',
      score: null,
      status: null,
      dataDate: null,
    );
  } else if (mvrvAsync.hasError) {
    mvrvIndicator = const IndicatorSummaryModel(
      label: 'MVRV Z-Score',
      value: '에러 발생',
      score: null,
      status: null,
      dataDate: null,
    );
  } else {
    final mvrvModel = mvrvAsync.requireValue;
    final mvrvScore = calculateMvrvScore(mvrvModel.mvrvZScore);
    final mvrvStatus = getMvrvStatus(mvrvModel.mvrvZScore);

    mvrvIndicator = IndicatorSummaryModel(
      label: 'MVRV Z-Score',
      value: mvrvModel.mvrvZScore.toStringAsFixed(2),
      score: mvrvScore,
      status: mvrvStatus,
      dataDate: mvrvModel.date,
    );

    valuationList.add(WeightedScore(score: mvrvScore, weight: mvrvWeight));
  }

  // ================================
  // 2. Cycle Timing
  // ================================
  // 2-1. 고점 및 저점 기반 예측
  final cycleTimingAnalysis = ref.watch(cycleTimingAnalysisProvider);

  final formattedRangeStart = DateFormat(
    'yyyy/MM/dd',
  ).format(cycleTimingAnalysis.targetEstimate.rangeStartDate);
  final formattedRangeEnd = DateFormat(
    'yyyy/MM/dd',
  ).format(cycleTimingAnalysis.targetEstimate.rangeEndDate);

  final estimateLabel = switch (cycleTimingAnalysis.targetEstimate.type) {
    CycleTimingEstimateType.top => '예상 고점',
    CycleTimingEstimateType.bottom => '예상 저점',
  };

  final timingRangeIndicator = IndicatorSummaryModel(
    label: '고·저점 주기 분석',
    value: '$estimateLabel: $formattedRangeStart ~ $formattedRangeEnd',
    score: cycleTimingAnalysis.score,
    status: cycleTimingAnalysis.status,
  );

  cycleTimingList.add(
    WeightedScore(score: cycleTimingAnalysis.score, weight: cycleTimingAnalysisWeight),
  );

  // ================================
  // 3. Trend
  // ================================
  final trendAsync = ref.watch(trendProvider);

  final TrendDetailModel trendDetailModel;

  if (trendAsync.hasValue) {
    trendDetailModel = trendAsync.requireValue;
  } else {
    trendDetailModel = TrendDetailModel(
      summary: CycleIndicatorModel(
        type: CycleIndicatorType.trend,
        title: '추세',
        score: null,
        weight: kTrendWeight,
        indicators: const [],
      ),
      chartData: const TrendChartDataModel(
        price: [],
        trendBaseline: [],
        upperTrendThreshold: [],
        lowerTrendThreshold: [],
        bottomRangeBoundary: [],
      ),
    );
  }
  // ================================
  // 4. Sentiment
  // ================================
  final fearGreedAsync = ref.watch(fearGreedProvider);
  final fundingRateAsync = ref.watch(fundingRateProvider);
  final IndicatorSummaryModel fearGreedIndicator;
  final IndicatorSummaryModel fundingRateIndicator;

  // 4-1. Fear & Greed
  if (fearGreedAsync.isLoading) {
    fearGreedIndicator = const IndicatorSummaryModel(
      label: 'Fear & Greed',
      value: '로딩 중...',
      score: null,
      status: null,
    );
  } else if (fearGreedAsync.hasError) {
    fearGreedIndicator = const IndicatorSummaryModel(
      label: 'Fear & Greed',
      value: '에러 발생',
      score: null,
      status: null,
    );
  } else {
    final fearGreedModel = fearGreedAsync.requireValue;
    final fearGreedValue = fearGreedModel.value;
    final fearGreedScore = fearGreedValue;
    final fearGreedStatus = getFearGreedStatus(fearGreedValue);

    fearGreedIndicator = IndicatorSummaryModel(
      label: 'Fear & Greed',
      value: fearGreedValue.toString(),
      score: fearGreedScore,
      status: fearGreedStatus,
    );

    sentimentList.add(WeightedScore(score: fearGreedScore, weight: fearGreedWeight));
  }

  // 4-2. Funding Rate
  if (fundingRateAsync.isLoading) {
    fundingRateIndicator = const IndicatorSummaryModel(
      label: 'Funding Rate',
      value: '로딩 중...',
      score: null,
      status: null,
    );
  } else if (fundingRateAsync.hasError) {
    fundingRateIndicator = const IndicatorSummaryModel(
      label: 'Funding Rate',
      value: '에러 발생',
      score: null,
      status: null,
    );
  } else {
    final fundingRateModel = fundingRateAsync.requireValue;
    final fundingRatePercent = fundingRateModel.lastFundingRate * 100;
    final fundingRateScore = calculateFundingRateScore(fundingRatePercent);
    final fundingRateStatus = getFundingRateStatus(fundingRatePercent);

    fundingRateIndicator = IndicatorSummaryModel(
      label: 'Funding Rate (BTC)',
      value: '${fundingRatePercent.toStringAsFixed(5)}%',
      score: fundingRateScore,
      status: fundingRateStatus,
    );

    sentimentList.add(WeightedScore(score: fundingRateScore, weight: fundingRateWeight));
  }

  // ================================
  // 각 카테고리의 Score값 계산
  // ================================
  final valuationScore = calculateCategoryScore(indicatorList: valuationList);
  final cycleTimingScore = calculateCategoryScore(indicatorList: cycleTimingList);
  final sentimentScore = calculateCategoryScore(indicatorList: sentimentList);

  final valuationModel = CycleIndicatorModel(
    type: CycleIndicatorType.valuation,
    title: '가치평가',
    score: valuationScore,
    weight: kValuationWeight,
    indicators: [mvrvIndicator],
  );

  final cycleTimingModel = CycleIndicatorModel(
    type: CycleIndicatorType.cycleTiming,
    title: '사이클 타이밍',
    score: cycleTimingScore,
    weight: kCycleTimingWeight,
    indicators: [timingRangeIndicator],
  );

  final sentimentModel = CycleIndicatorModel(
    type: CycleIndicatorType.sentiment,
    title: '심리/레버리지',
    score: sentimentScore,
    weight: kSentimentWeight,
    indicators: [fearGreedIndicator, fundingRateIndicator],
  );

  return CycleIndicators(
    valuation: valuationModel,
    cycleTiming: cycleTimingModel,
    trend: trendDetailModel,
    sentiment: sentimentModel,
  );
});
