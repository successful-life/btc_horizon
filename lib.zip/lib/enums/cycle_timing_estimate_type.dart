enum CycleTimingEstimateType { top, bottom }
